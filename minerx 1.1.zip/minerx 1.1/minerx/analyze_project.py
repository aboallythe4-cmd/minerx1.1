import os

def analyze_directory_structure(root_dir, output_file):
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("📦 Project Structure Analysis\n")
        f.write("=" * 40 + "\n\n")

        for foldername, subfolders, filenames in os.walk(root_dir):
            level = foldername.replace(root_dir, '').count(os.sep)
            indent = ' ' * 2 * level
            f.write(f"{indent}📁 {os.path.basename(foldername) or foldername}\n")
            sub_indent = ' ' * 2 * (level + 1)

            for filename in filenames:
                filepath = os.path.join(foldername, filename)
                if filename.endswith(('.js', '.jsx', '.ts', '.tsx')):
                    f.write(f"{sub_indent}🟦 JS/TS File: {filename}\n")
                elif filename.endswith(('.html', '.css')):
                    f.write(f"{sub_indent}🟩 Frontend File: {filename}\n")
                elif filename.endswith(('.php', '.py', '.rb', '.go')):
                    f.write(f"{sub_indent}🟨 Backend File: {filename}\n")
                elif filename.endswith(('.env', '.json', '.config', '.yml', '.yaml')):
                    f.write(f"{sub_indent}⚙️ Config File: {filename}\n")
                elif filename.endswith(('.sql', '.db', '.sqlite')):
                    f.write(f"{sub_indent}🧩 Database File: {filename}\n")
                else:
                    f.write(f"{sub_indent}📄 Other: {filename}\n")
            f.write("\n")

    print(f"✅ Analysis complete! Report saved as: {output_file}")

# 🔧 غيّر هذا إلى المسار الكامل لمجلد المشروع بعد فك الضغط
project_directory = "."
output_report = "project_structure.txt"

analyze_directory_structure(project_directory, output_report)
