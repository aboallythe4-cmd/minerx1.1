// حماية الصفحة
const token = localStorage.getItem("token");
if (!token) {
  window.location.href = "login.html"; // إذا لم يسجل الدخول، نرجعه للصفحة الرئيسية
}

// جلب بيانات المستخدم من السيرفر
fetch("http://localhost:3000/api/user/dashboard", {
  headers: {
    Authorization: "Bearer " + token
  }
})
  .then(res => res.json())
  .then(data => {
    document.getElementById("user-name").textContent = data.name;
    document.getElementById("balance").textContent = data.balance + " USD";
    document.getElementById("total-deposits").textContent = data.deposits + " USD";
    document.getElementById("total-withdrawals").textContent = data.withdrawals + " USD";
  })
  .catch(err => console.error("Error:", err));

// زر تسجيل الخروج
function logout() {
  localStorage.removeItem("token");
  window.location.href = "login.html";
}
