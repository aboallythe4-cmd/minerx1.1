// -------------------------------
// 🔄 تحديث الرصيد من قاعدة البيانات
// -------------------------------
async function fetchBalance() {
  try {
    const response = await fetch('/api/get-balance', { credentials: 'include' });
    if (!response.ok) throw new Error('HTTP error ' + response.status);
    const data = await response.json();

    if (data && typeof data.balance !== 'undefined') {
      const balanceEl = document.querySelector('.balance');
      balanceEl.textContent = `$${parseFloat(data.balance).toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
    }
  } catch (err) {
    console.error('❌ فشل جلب الرصيد:', err);
  }
}

// -------------------------------
// 🕒 تشغيل عند تحميل الصفحة
// -------------------------------
document.addEventListener('DOMContentLoaded', () => {
  // جلب الرصيد فورًا
  fetchBalance();

  // تحديث الرصيد كل 30 ثانية
  setInterval(fetchBalance, 30000);
});

// -------------------------------
// 📋 تحسين النسخ الاحتياطي
// -------------------------------
function copyFallback(text) {
  const textarea = document.createElement('textarea');
  textarea.value = text;
  document.body.appendChild(textarea);
  textarea.select();
  try {
    document.execCommand('copy');
    alert('✅ تم نسخ العنوان بنجاح!');
  } catch (err) {
    alert('❌ تعذر النسخ تلقائيًا. انسخ يدويًا.');
  }
  document.body.removeChild(textarea);
}

// إعادة تعريف دالة النسخ لتشمل fallback
window.copyAddress = function (walletType) {
  const text = document.getElementById(walletType + 'AddressText').textContent.trim();

  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text)
      .then(() => alert('✅ تم نسخ العنوان بنجاح!'))
      .catch(() => copyFallback(text));
  } else {
    copyFallback(text);
  }
};

// -------------------------------
// 🔔 مراقبة الإيداعات الجديدة (اختياري)
// -------------------------------
async function watchDeposits() {
  try {
    const res = await fetch('/api/check-deposit-status', { credentials: 'include' });
    if (!res.ok) throw new Error('HTTP error ' + res.status);
    const data = await res.json();

    if (data.newDeposit) {
      alert('💰 تم تأكيد إيداع جديد! تم تحديث رصيدك.');
      fetchBalance();
    }
  } catch (err) {
    console.error('⚠️ فشل في مراقبة الإيداعات:', err);
  }
}

// مراقبة الإيداعات كل 45 ثانية (اختياري)
setInterval(watchDeposits, 45000);
