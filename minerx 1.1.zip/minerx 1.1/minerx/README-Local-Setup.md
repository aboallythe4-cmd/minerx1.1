# MinerX-v2 (Local Test Build)

This is a local test build of MinerX v2 including an admin panel.
Follow these steps to run locally:

1. Install dependencies (backend):
   ```
   cd backend
   npm install
   ```

2. Create MySQL database:
   ```
   CREATE DATABASE minerx_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```

3. Copy .env.example to .env and edit values:
   ```
   cp ../.env.example .env
   ```

4. Run the server:
   ```
   npm run dev
   ```

Server will run on http://localhost:3000

Front-end files are static in /frontend. Open frontend/index.html in browser.
Admin panel: frontend/admin/login.html

Note: MAIL_ENABLED=false by default. When false, verification emails are printed to server console (for safe local testing).
