const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');
const Admin = sequelize.define('Admin', {
  id: { type: DataTypes.BIGINT.UNSIGNED, autoIncrement: true, primaryKey: true },
  email: { type: DataTypes.STRING, allowNull: false, unique: true },
  password: { type: DataTypes.STRING, allowNull: false },
  role: { type: DataTypes.ENUM('superadmin','assistant'), defaultValue: 'assistant' },
  name: { type: DataTypes.STRING }
});
module.exports = Admin;
