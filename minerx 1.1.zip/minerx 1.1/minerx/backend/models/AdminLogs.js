const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');
const AdminLogs = sequelize.define('AdminLogs', {
  id: { type: DataTypes.BIGINT.UNSIGNED, autoIncrement: true, primaryKey: true },
  adminId: { type: DataTypes.BIGINT.UNSIGNED, allowNull: false },
  action: { type: DataTypes.STRING },
  meta: { type: DataTypes.TEXT },
  ip: { type: DataTypes.STRING }
});
module.exports = AdminLogs;
