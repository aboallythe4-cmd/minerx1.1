const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');
const Investment = sequelize.define('Investment', {
  id: { type: DataTypes.BIGINT.UNSIGNED, autoIncrement: true, primaryKey: true },
  userId: { type: DataTypes.BIGINT.UNSIGNED, allowNull: false },
  plan: { type: DataTypes.STRING },
  amount: { type: DataTypes.DOUBLE },
  expectedProfit: { type: DataTypes.DOUBLE },
  status: { type: DataTypes.STRING, defaultValue: 'active' }
});
module.exports = Investment;
