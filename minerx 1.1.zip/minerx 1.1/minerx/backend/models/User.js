// 📦 backend/models/User.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

// 🧩 تعريف نموذج المستخدم User
const User = sequelize.define('User', {
  // 🆔 المعرف الفريد لكل مستخدم
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },

  // 👤 اسم المستخدم
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },

  // 📧 البريد الإلكتروني (فريد)
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
    validate: {
      isEmail: true,
    },
  },

  // 🔑 كلمة المرور (مشفّرة)
  password: {
    type: DataTypes.STRING,
    allowNull: false,
  },

  // 💰 الرصيد الحالي للمستخدم
  balance: {
    type: DataTypes.DECIMAL(12, 2),
    defaultValue: 0.00,
    allowNull: false,
  },

  // ✅ حالة التحقق من البريد
  verified: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },

  // 🧭 الدور (user / admin)
  role: {
    type: DataTypes.STRING,
    defaultValue: 'user',
  },
}, {
  timestamps: true, // 🔄 يسجّل createdAt و updatedAt تلقائيًا
});

module.exports = User;
