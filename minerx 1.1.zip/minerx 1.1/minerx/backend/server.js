require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path'); // ✅ أضفناها بشكل صحيح
const sequelize = require('./config/db');

const app = express();

// ✅ هذا السطر يجعل مجلد frontend متاحًا عبر المتصفح
app.use(cors());
app.use(express.json());
app.use('/frontend', express.static(path.join(__dirname, '../frontend')));
app.use('/api/transaction', require('./routes/transaction.routes'));
// 📦 استيراد وحدة الإيداع
const depositController = require("./controllers/deposit.controller");
const authMiddleware = require("./middlewares/auth.middleware");
// ✅ مسار تنفيذ عملية الإيداع
app.use("/api/deposit", require("./routes/deposit.routes"));
app.post("/api/deposit", authMiddleware, depositController.handleDeposit);
// ✅ Routes
app.use(process.env.API_PREFIX + '/auth', require('./routes/auth.routes'));
app.use(process.env.API_PREFIX + '/admin', require('./routes/admin.routes'));
const userRoutes = require('./routes/user.routes');
app.use('/api/user', userRoutes);

// ✅ مسار صحي للتجربة
app.get('/', (req, res) => res.json({ ok: true, msg: 'MinerX API running' }));

// ✅ تشغيل السيرفر
(async () => {
  try {
    await sequelize.authenticate();
    await sequelize.sync();
    console.log('DB connected and models synced');

    const PORT = process.env.PORT || 3000;
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  } catch (err) {
    console.error('Unable to start server', err);
  }
})();
