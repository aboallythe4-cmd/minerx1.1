const nodemailer = require('nodemailer');
require('dotenv').config();

const MAIL_ENABLED = (process.env.MAIL_ENABLED === 'true');

let transporter = null;
if (MAIL_ENABLED) {
  transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: { user: process.env.GMAIL_USER, pass: process.env.GMAIL_PASS }
  });
}

/**
 * إرسال رسالة تفعيل الحساب
 */
async function sendVerificationEmail(to, verifyUrl) {
  const subject = '🔐 تفعيل حسابك في MinerX';
  const html = `
  <div style="font-family:'Segoe UI',sans-serif;background:#f4f5fb;padding:30px;">
    <div style="max-width:600px;margin:auto;background:white;border-radius:15px;overflow:hidden;
                box-shadow:0 5px 20px rgba(0,0,0,0.1)">
      <div style="background:linear-gradient(135deg,#667eea,#764ba2);padding:20px;color:white;text-align:center">
        <h2 style="margin:0;">🌐 MinerX</h2>
        <p style="margin:0;font-size:14px;">منصة التعدين السحابي المتطورة</p>
      </div>
      <div style="padding:30px;text-align:center;">
        <h3>مرحبًا بك في MinerX!</h3>
        <p>يرجى تفعيل حسابك عبر الضغط على الزر أدناه:</p>
        <a href="${verifyUrl}" target="_blank"
           style="display:inline-block;margin-top:15px;padding:12px 25px;background:linear-gradient(135deg,#667eea,#764ba2);
                  color:white;text-decoration:none;border-radius:8px;font-weight:bold;">
          تفعيل الحساب
        </a>
        <p style="margin-top:20px;font-size:13px;color:#888;">إذا لم تنشئ حسابًا في MinerX، تجاهل هذه الرسالة.</p>
      </div>
    </div>
  </div>`;

  if (!MAIL_ENABLED) {
    console.log('📧 [MAIL DISABLED] Verification link for', to, ':', verifyUrl);
    return Promise.resolve();
  }

  return transporter.sendMail({ from: `"MinerX" <${process.env.GMAIL_USER}>`, to, subject, html });
}

/**
 * إرسال رابط إعادة تعيين كلمة المرور
 */
async function sendPasswordResetEmail(to, resetUrl) {
  const subject = '🔑 إعادة تعيين كلمة المرور - MinerX';
  const html = `
  <div style="font-family:'Segoe UI',sans-serif;background:#f4f5fb;padding:30px;">
    <div style="max-width:600px;margin:auto;background:white;border-radius:15px;overflow:hidden;
                box-shadow:0 5px 20px rgba(0,0,0,0.1)">
      <div style="background:linear-gradient(135deg,#667eea,#764ba2);padding:20px;color:white;text-align:center">
        <h2 style="margin:0;">🔑 MinerX</h2>
        <p style="margin:0;font-size:14px;">طلب إعادة تعيين كلمة المرور</p>
      </div>
      <div style="padding:30px;text-align:center;">
        <p>لقد طلبت إعادة تعيين كلمة المرور الخاصة بحسابك في MinerX.</p>
        <p>اضغط على الزر أدناه لتعيين كلمة مرور جديدة (صالح لمدة ساعة واحدة):</p>
        <a href="${resetUrl}" target="_blank"
           style="display:inline-block;margin-top:15px;padding:12px 25px;background:linear-gradient(135deg,#667eea,#764ba2);
                  color:white;text-decoration:none;border-radius:8px;font-weight:bold;">
          إعادة تعيين كلمة المرور
        </a>
        <p style="margin-top:20px;font-size:13px;color:#888;">إذا لم تطلب هذا الإجراء، يمكنك تجاهل هذه الرسالة.</p>
      </div>
    </div>
  </div>`;

  if (!MAIL_ENABLED) {
    console.log('📧 [MAIL DISABLED] Reset link for', to, ':', resetUrl);
    return Promise.resolve();
  }

  return transporter.sendMail({ from: `"MinerX" <${process.env.GMAIL_USER}>`, to, subject, html });
}

module.exports = { sendVerificationEmail, sendPasswordResetEmail };
