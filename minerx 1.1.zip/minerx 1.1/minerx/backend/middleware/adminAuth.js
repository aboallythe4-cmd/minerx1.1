const jwt = require('jsonwebtoken');
const Admin = require('../models/Admin');
require('dotenv').config();

async function adminAuth(req,res,next){
  try{
    const authHeader = req.headers.authorization;
    if(!authHeader) return res.status(401).json({message:'No token'});
    const parts = authHeader.split(' ');
    if(parts.length!==2) return res.status(401).json({message:'Invalid token'});
    const token = parts[1];
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const admin = await Admin.findByPk(payload.id);
    if(!admin) return res.status(401).json({message:'Invalid admin'});
    req.admin = { id: admin.id, role: admin.role, email: admin.email };
    // role-based: assistant cannot access settings route for example (handled in controllers/routes)
    next();
  }catch(err){ console.error(err); return res.status(401).json({message:'Unauthorized'}); }
}

module.exports = { adminAuth };
