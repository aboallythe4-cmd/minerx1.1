// 📂 backend/controllers/deposit.controller.js
const User = require("../models/User");
const Transaction = require("../models/Transaction");

/**
 * @desc معالجة عملية الإيداع
 * @route POST /api/deposit
 * @access Private (JWT)
 */
exports.handleDeposit = async (req, res) => {
  try {
    const { amount, currency } = req.body;

    // ✅ تحقق من صحة البيانات
    if (!amount || !currency) {
      return res.status(400).json({ message: "البيانات غير مكتملة" });
    }

    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: "المستخدم غير موجود" });
    }

    // ✅ التحقق من الحد الأدنى للإيداع
    if (
      (currency === "SOL" && amount < 0.1) ||
      (currency === "USDT" && amount < 10)
    ) {
      return res.status(400).json({ message: "المبلغ أقل من الحد الأدنى المسموح به" });
    }

    // 💰 تحديث رصيد المستخدم
    user.balance = (user.balance || 0) + Number(amount);
    await user.save();

    // 🧾 إنشاء سجل العملية
    await Transaction.create({
      userId: user._id,
      type: "deposit",
      currency,
      amount,
      status: "confirmed",
      createdAt: new Date()
    });

    // 📤 رد النجاح
    res.status(200).json({
      message: "تم الإيداع بنجاح ✅",
      newBalance: user.balance,
    });

  } catch (error) {
    console.error("❌ خطأ في الإيداع:", error);
    res.status(500).json({ message: "حدث خطأ في الخادم، حاول لاحقًا" });
  }
};
