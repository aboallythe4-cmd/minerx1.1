const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const crypto = require('crypto');
const { sendVerificationEmail, sendPasswordResetEmail } = require('../utils/mailer');
require('dotenv').config();

/**
 * تسجيل مستخدم جديد + إرسال رابط تفعيل إلى البريد الإلكتروني
 */
async function register(req, res) {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password)
      return res.status(400).json({ message: 'الرجاء إدخال جميع الحقول المطلوبة / Missing required fields' });

    // تحقق إن كان البريد مسجل مسبقًا
    const existing = await User.findOne({ where: { email } });
    if (existing)
      return res.status(400).json({ message: 'هذا البريد مسجل مسبقًا / Email already registered' });

    // تشفير كلمة المرور
    const hashed = await bcrypt.hash(password, 10);

    // إنشاء المستخدم غير المفعل
    const user = await User.create({
      name,
      email,
      password: hashed,
      verified: false,
    });

    // إنشاء رمز JWT صالح لمدة 24 ساعة
    const token = jwt.sign(
      { id: user.id, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: '1d' }
    );

    // إنشاء رابط التفعيل
    const verifyUrl = `http://localhost:3000/api/auth/verify-email?token=${token}`;

    // إرسال البريد الإلكتروني
    await sendVerificationEmail(user.email, verifyUrl);

    res.status(201).json({
      success: true,
      message: 'تم التسجيل بنجاح! تحقق من بريدك الإلكتروني لتفعيل الحساب / Registration successful! Please check your email.',
    });
  } catch (err) {
    console.error('❌ Registration error:', err);
    res.status(500).json({ message: 'حدث خطأ في الخادم / Server error' });
  }
}

/**
 * تفعيل البريد الإلكتروني عند الضغط على الرابط
 */
async function verifyEmail(req, res) {
  try {
    const { token } = req.query;
    console.log("🔍 Incoming verification token:", token ? "Received" : "Missing");

    if (!token)
      return res.status(400).json({ message: 'رابط التفعيل غير صالح / Verification token missing' });

    // فك التوكن والتحقق منه
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
      console.error("❌ JWT verification error:", err.message);
      return res.status(400).json({ message: 'الرابط منتهي أو غير صالح / Invalid or expired link' });
    }

    console.log("✅ Token decoded:", decoded);

    const user = await User.findByPk(decoded.id);

    if (!user)
      return res.status(404).json({ message: 'المستخدم غير موجود / User not found' });

    if (user.verified)
      return res.status(200).json({ message: 'تم التفعيل مسبقًا / Email already verified' });

    user.verified = true;
    await user.save();

    console.log("✅ User verified:", user.email);
    return res.status(200).json({ success: true, message: 'تم تفعيل البريد الإلكتروني بنجاح / Email verified successfully' });
  } catch (err) {
    console.error('❌ Verification error:', err);
    res.status(500).json({ message: 'حدث خطأ أثناء عملية التفعيل / Server error during verification' });
  }
}

/**
 * تسجيل الدخول بعد التفعيل
 */
async function login(req, res) {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ where: { email } });
    if (!user)
      return res.status(400).json({ message: 'بيانات الدخول غير صحيحة / Invalid credentials' });

    const ok = await bcrypt.compare(password, user.password);
    if (!ok)
      return res.status(400).json({ message: 'بيانات الدخول غير صحيحة / Invalid credentials' });

    if (!user.verified)
      return res.status(403).json({ message: 'يرجى تفعيل البريد الإلكتروني أولًا / Please verify your email first' });

    const token = jwt.sign(
      { id: user.id, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    );

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
      },
    });
  } catch (err) {
    console.error('❌ Login error:', err);
    res.status(500).json({ message: 'حدث خطأ في تسجيل الدخول / Server error during login' });
  }
}

/**
 * إرسال رابط إعادة تعيين كلمة المرور
 */
async function forgotPassword(req, res) {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ message: 'Email is required' });

    const user = await User.findOne({ where: { email } });
    if (!user) return res.status(404).json({ message: 'No account found for this email' });

    // إنشاء توكن مؤقت
    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });

    // توليد رابط إعادة التعيين
    const resetUrl = `http://localhost:3000/frontend/reset.html?token=${token}`;

    // إرسال البريد
    await sendPasswordResetEmail(email, resetUrl);

    res.json({ success: true, message: 'Password reset link sent to your email' });
  } catch (err) {
    console.error('❌ Forgot password error:', err);
    res.status(500).json({ message: 'Server error' });
  }
}

/**
 * تعيين كلمة مرور جديدة
 */
async function resetPassword(req, res) {
  try {
    const { token, password } = req.body;
    if (!token || !password)
      return res.status(400).json({ message: 'Missing token or password' });

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findByPk(decoded.id);
    if (!user) return res.status(404).json({ message: 'User not found' });

    const hashed = await bcrypt.hash(password, 10);
    user.password = hashed;
    await user.save();

    res.json({ success: true, message: 'Password reset successfully' });
  } catch (err) {
    console.error('❌ Reset password error:', err);
    res.status(400).json({ message: 'Invalid or expired token' });
  }
}

module.exports = {
  register,
  verifyEmail,
  login,
  forgotPassword,
  resetPassword
};
