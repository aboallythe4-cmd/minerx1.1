const User = require('../models/User');
const Transaction = require('../models/Transaction');

/** 💰 إيداع فوري */
async function deposit(req, res) {
  try {
    const { amount, currency } = req.body;
    if (!amount || amount <= 0) return res.status(400).json({ message: 'Invalid amount' });

    const user = await User.findByPk(req.user.id);
    if (!user) return res.status(404).json({ message: 'User not found' });

    // تحديث الرصيد
    user.balance = parseFloat(user.balance) + parseFloat(amount);
    await user.save();

    // حفظ العملية
    await Transaction.create({ userId: user.id, type: 'deposit', amount, currency, status: 'completed' });

    res.json({ success: true, message: 'Deposit successful', balance: user.balance });
  } catch (err) {
    console.error('Deposit error:', err);
    res.status(500).json({ message: 'Server error' });
  }
}

/** 💸 سحب */
async function withdraw(req, res) {
  try {
    const { amount, currency } = req.body;
    if (!amount || amount <= 0) return res.status(400).json({ message: 'Invalid amount' });

    const user = await User.findByPk(req.user.id);
    if (!user) return res.status(404).json({ message: 'User not found' });

    if (user.balance < amount)
      return res.status(400).json({ message: 'رصيد غير كافٍ / Insufficient balance' });

    user.balance = parseFloat(user.balance) - parseFloat(amount);
    await user.save();

    await Transaction.create({ userId: user.id, type: 'withdraw', amount, currency, status: 'completed' });

    res.json({ success: true, message: 'Withdrawal successful', balance: user.balance });
  } catch (err) {
    console.error('Withdraw error:', err);
    res.status(500).json({ message: 'Server error' });
  }
}

/** 🔍 استعلام عن الرصيد */
async function getBalance(req, res) {
  try {
    const user = await User.findByPk(req.user.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json({ balance: user.balance });
  } catch (err) {
    console.error('Balance error:', err);
    res.status(500).json({ message: 'Server error' });
  }
}

/** 🧾 استعلام عن العمليات */
async function getTransactions(req, res) {
  try {
    const transactions = await Transaction.findAll({
      where: { userId: req.user.id },
      order: [['createdAt', 'DESC']]
    });
    res.json(transactions);
  } catch (err) {
    console.error('Transactions error:', err);
    res.status(500).json({ message: 'Server error' });
  }
}

module.exports = { deposit, withdraw, getBalance, getTransactions };
