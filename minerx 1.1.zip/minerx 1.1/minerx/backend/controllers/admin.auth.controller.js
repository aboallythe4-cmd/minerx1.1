const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const Admin = require('../models/Admin');
require('dotenv').config();

async function adminLogin(req,res){
  try{
    const { email,password } = req.body;
    const admin = await Admin.findOne({where:{email}});
    if(!admin) return res.status(400).json({message:'Invalid credentials'});
    const ok = await bcrypt.compare(password, admin.password);
    if(!ok) return res.status(400).json({message:'Invalid credentials'});
    const token = jwt.sign({id:admin.id, email:admin.email, role:admin.role}, process.env.JWT_SECRET, {expiresIn:process.env.JWT_EXPIRES_IN});
    res.json({success:true, token, admin:{id:admin.id,email:admin.email,role:admin.role,name:admin.name}});
  }catch(err){console.error(err); res.status(500).json({message:'Server error'});}
}

module.exports = { adminLogin };
