const Admin = require('../models/Admin');
const AdminLogs = require('../models/AdminLogs');
const User = require('../models/User');
const Transaction = require('../models/Transaction');

async function getStats(req,res){
  try{
    const usersCount = await User.count();
    const deposits = await Transaction.sum('amount', { where: { type: 'deposit' } }) || 0;
    const withdrawals = await Transaction.sum('amount', { where: { type: 'withdraw' } }) || 0;
    res.json({ usersCount, deposits, withdrawals });
  }catch(err){console.error(err); res.status(500).json({message:'Server error'});}
}

async function listUsers(req,res){
  try{
    const users = await User.findAll({ attributes: { exclude: ['password','verificationCode'] }});
    res.json(users);
  }catch(err){console.error(err); res.status(500).json({message:'Server error'});}
}

async function listTransactions(req,res){
  try{
    const txs = await Transaction.findAll({ order: [['createdAt','DESC']] });
    res.json(txs);
  }catch(err){console.error(err); res.status(500).json({message:'Server error'});}
}

async function approveTransaction(req,res){
  try{
    const { id } = req.params;
    const tx = await Transaction.findByPk(id);
    if(!tx) return res.status(404).json({message:'Not found'});
    tx.status = 'completed';
    await tx.save();
    await AdminLogs.create({ adminId: req.admin.id, action: 'approve_transaction', meta: JSON.stringify({ txId:id }), ip: req.ip });
    res.json({ success:true });
  }catch(err){console.error(err); res.status(500).json({message:'Server error'});}
}

module.exports = { getStats, listUsers, listTransactions, approveTransaction };
