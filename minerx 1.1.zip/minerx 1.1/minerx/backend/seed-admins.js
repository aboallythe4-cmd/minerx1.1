/*
 Run once to create initial admin users:
 node seed-admins.js
*/
const bcrypt = require('bcrypt');
const sequelize = require('./config/db');
const Admin = require('./models/Admin');

(async()=>{
  try{
    await sequelize.authenticate();
    await sequelize.sync();
    const pass1 = await bcrypt.hash('Admin@123',10);
    const pass2 = await bcrypt.hash('Assist@123',10);
    await Admin.findOrCreate({ where:{ email: 'admin@minerx.com' }, defaults:{ password: pass1, role:'superadmin', name:'Super Admin' }});
    await Admin.findOrCreate({ where:{ email: 'assistant@minerx.com' }, defaults:{ password: pass2, role:'assistant', name:'Assistant Admin' }});
    console.log('Seeded admins');
    process.exit(0);
  }catch(err){ console.error(err); process.exit(1); }
})();
