const express = require('express');
const router = express.Router();
const { adminLogin } = require('../controllers/admin.auth.controller');
const adminController = require('../controllers/admin.controller');
const { adminAuth } = require('../middleware/adminAuth');

// auth
router.post('/auth/login', adminLogin);

// protected routes
router.get('/stats', adminAuth, adminController.getStats);
router.get('/users', adminAuth, adminController.listUsers);
router.get('/transactions', adminAuth, adminController.listTransactions);
router.put('/transactions/:id/approve', adminAuth, adminController.approveTransaction);

module.exports = router;
