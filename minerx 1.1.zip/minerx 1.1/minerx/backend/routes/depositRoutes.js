const express = require('express');
const router = express.Router();
const db = require('../db'); // الاتصال بقاعدة البيانات
const jwt = require('jsonwebtoken');

// 🟢 إضافة عملية إيداع
router.post('/', (req, res) => {
  const { amount } = req.body;
  const token = req.headers.authorization?.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, message: 'لم يتم تسجيل الدخول' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.id;

    // تحقق من صحة المبلغ
    const depositAmount = parseFloat(amount);
    if (isNaN(depositAmount) || depositAmount <= 0) {
      return res.status(400).json({ success: false, message: 'مبلغ غير صالح' });
    }

    // 1️⃣ تسجيل العملية في جدول deposits
    db.query(
      'INSERT INTO deposits (user_id, amount, created_at) VALUES (?, ?, NOW())',
      [userId, depositAmount],
      (err) => {
        if (err) {
          console.error(err);
          return res.status(500).json({ success: false, message: 'خطأ في حفظ العملية' });
        }

        // 2️⃣ تحديث الرصيد في جدول users
        db.query(
          'UPDATE users SET balance = balance + ? WHERE id = ?',
          [depositAmount, userId],
          (err2) => {
            if (err2) {
              console.error(err2);
              return res.status(500).json({ success: false, message: 'فشل تحديث الرصيد' });
            }

            // 3️⃣ إعادة الرصيد الجديد
            db.query('SELECT balance FROM users WHERE id = ?', [userId], (err3, results) => {
              if (err3) {
                console.error(err3);
                return res.status(500).json({ success: false });
              }

              res.json({
                success: true,
                message: 'تم الإيداع بنجاح',
                newBalance: results[0].balance
              });
            });
          }
        );
      }
    );
  } catch (error) {
    console.error(error);
    res.status(401).json({ success: false, message: 'رمز مميز غير صالح' });
  }
});

module.exports = router;
