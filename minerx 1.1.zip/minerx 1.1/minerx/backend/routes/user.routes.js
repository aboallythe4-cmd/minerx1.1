const express = require('express');
const router = express.Router();
const User = require('../models/User');
const authMiddleware = require('../middlewares/auth.middleware'); // ✅ تأكد من اسم المجلد الصحيح

// 🧩 جلب بيانات المستخدم للوحة التحكم
router.get('/dashboard', authMiddleware, async (req, res) => {
  try {
    const user = await User.findByPk(req.user.id);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // 🔄 حساب مجموع الإيداعات والسحوبات
    const transactions = await require('../models/Transaction').findAll({
      where: { userId: user.id },
    });

    let deposits = 0;
    let withdrawals = 0;

    transactions.forEach((tx) => {
      if (tx.type === 'deposit') deposits += parseFloat(tx.amount);
      if (tx.type === 'withdraw') withdrawals += parseFloat(tx.amount);
    });

    // 💰 الأرباح = الرصيد - (الإيداعات - السحوبات)
    const profit = parseFloat(user.balance) - (deposits - withdrawals);

    res.json({
      name: user.name,
      email: user.email,
      balance: user.balance,
      deposits,
      withdrawals,
      profit,
    });
  } catch (err) {
    console.error('❌ Dashboard error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});
    // ✅ إرسال البيانات الفعلية من قاعدة البيانات بدل القيم التجريبية
    res.json({
      name: user.name,
      balance: user.balance,        // الرصيد الفعلي
      deposits: 0,                  // يمكنك لاحقًا حسابها من جدول المعاملات
      withdrawals: 0                // كذلك
    });
  } catch (err) {
    console.error('❌ Dashboard error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// ✅ جلب بيانات المستخدم الحالي (للإيداع والصفحات الشخصية)
router.get('/me', authMiddleware, async (req, res) => {
  try {
    const user = await User.findByPk(req.user.id, {
      attributes: ['id', 'name', 'email', 'balance', 'role']
    });

    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json(user);
  } catch (err) {
    console.error('Error fetching user data:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
