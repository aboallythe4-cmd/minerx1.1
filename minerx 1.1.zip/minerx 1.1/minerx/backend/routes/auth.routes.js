const express = require('express');
const router = express.Router();

// استيراد جميع الدوال من نفس الملف مرة واحدة
const { 
  register, 
  verifyEmail, 
  login, 
  forgotPassword, 
  resetPassword 
} = require('../controllers/auth.controller');

// 🧩 تسجيل مستخدم جديد
router.post('/register', register);

// 🧩 التحقق من البريد الإلكتروني (GET)
router.get('/verify-email', verifyEmail);

// 🧩 تسجيل الدخول
router.post('/login', login);

// 🧩 إرسال رابط استعادة كلمة المرور
router.post('/forgot-password', forgotPassword);

// 🧩 إعادة تعيين كلمة المرور الجديدة
router.post('/reset-password', resetPassword);

module.exports = router;
