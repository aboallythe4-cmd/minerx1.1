const express = require('express');
const router = express.Router();
const { deposit, withdraw, getBalance, getTransactions } = require('../controllers/transaction.controller');
const { verifyToken } = require('../middleware/auth');

// 💰 إيداع
router.post('/deposit', verifyToken, deposit);

// 💸 سحب
router.post('/withdraw', verifyToken, withdraw);

// 🔍 الرصيد
router.get('/balance', verifyToken, getBalance);

// 🧾 العمليات السابقة
router.get('/history', verifyToken, getTransactions);

module.exports = router;
